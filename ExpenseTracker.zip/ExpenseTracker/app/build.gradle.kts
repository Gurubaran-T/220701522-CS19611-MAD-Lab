plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}
