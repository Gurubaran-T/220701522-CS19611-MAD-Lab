package com.example.expensetracker

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate

class ChartActivity : AppCompatActivity() {

    private lateinit var pieChart: PieChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart)

        // Set up toolbar
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.title = "Expense Chart"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        pieChart = findViewById(R.id.pieChart)

        // Get data from intent (in a real app, you'd get from database)
        val expenseList = intent.getSerializableExtra("expenseList") as ArrayList<Expense>
        val totalExpense = intent.getDoubleExtra("totalExpense", 0.0)

        setupPieChart(expenseList, totalExpense)
    }

    private fun setupPieChart(expenseList: ArrayList<Expense>, totalExpense: Double) {
        // Group expenses by category
        val categoryMap = mutableMapOf<String, Float>()
        for (expense in expenseList) {
            val currentAmount = categoryMap[expense.category] ?: 0f
            categoryMap[expense.category] = currentAmount + expense.amount.toFloat()
        }

        // Create entries for the pie chart
        val entries = ArrayList<PieEntry>()
        for ((category, amount) in categoryMap) {
            entries.add(PieEntry(amount, category))
        }

        val dataSet = PieDataSet(entries, "Expenses by Category")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
        dataSet.valueTextColor = Color.BLACK
        dataSet.valueTextSize = 12f

        val pieData = PieData(dataSet)
        pieChart.data = pieData
        pieChart.description.isEnabled = false
        pieChart.centerText = "Total: $$totalExpense"
        pieChart.animateY(1000)
        pieChart.invalidate()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}