package com.example.expensetracker

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*


const val RESULT_ADD = 1
const val RESULT_CANCEL = 0
class AddExpenseActivity : AppCompatActivity() {

    private lateinit var categorySpinner: Spinner
    private lateinit var amountEditText: EditText
    private lateinit var dateEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        // Set up toolbar
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.title = "Add New Expense"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Initialize views
        categorySpinner = findViewById(R.id.categorySpinner)
        amountEditText = findViewById(R.id.amountEditText)
        dateEditText = findViewById(R.id.dateEditText)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        saveButton = findViewById(R.id.saveButton)

        // Setup category spinner
        val categories = arrayOf("Food", "Transport", "Shopping", "Entertainment", "Bills", "Other")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        // Set current date as default
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        dateEditText.setText(dateFormat.format(Date()))
        dateEditText.setOnClickListener {
            showDatePicker()
        }
        // Save button click listener
        saveButton.setOnClickListener {
            if (validateInput()) {
                val category = categorySpinner.selectedItem.toString()
                val amount = amountEditText.text.toString().toDouble()
                val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(dateEditText.text.toString()) ?: Date()
                val description = descriptionEditText.text.toString()

                val newExpense = Expense(category, amount, date, description)

                val resultIntent = Intent()
                resultIntent.putExtra("newExpense", newExpense)
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(selectedYear, selectedMonth, selectedDay)
                dateEditText.setText(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedDate.time))
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }
    private fun validateInput(): Boolean {
        var isValid = true

        if (amountEditText.text.toString().isEmpty()) {
            amountEditText.error = "Please enter amount"
            isValid = false
        } else {
            try {
                amountEditText.text.toString().toDouble()
            } catch (e: NumberFormatException) {
                amountEditText.error = "Please enter a valid number"
                isValid = false
            }
        }

        if (dateEditText.text.toString().isEmpty()) {
            dateEditText.error = "Please select a date"
            isValid = false
        }

        return isValid
    }

    override fun onSupportNavigateUp(): Boolean {
        setResult(RESULT_CANCEL)
        finish()
        return true
    }
}