package com.example.expensetracker

import java.io.Serializable
import java.util.*

data class Expense(
    val category: String,
    val amount: Double,
    val date: Date,
    val description: String
) : Serializable