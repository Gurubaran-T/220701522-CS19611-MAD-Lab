package com.example.expensetracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class ExpenseAdapter(private val expenseList: ArrayList<Expense>) :
    RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    interface OnItemDeleteListener {
        fun onItemDelete(position: Int)
    }

    private var deleteListener: OnItemDeleteListener? = null

    fun setOnItemDeleteListener(listener: OnItemDeleteListener) {
        this.deleteListener = listener
    }

    class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val categoryText: TextView = itemView.findViewById(R.id.categoryText)
        val amountText: TextView = itemView.findViewById(R.id.amountText)
        val dateText: TextView = itemView.findViewById(R.id.dateText)
        val descriptionText: TextView = itemView.findViewById(R.id.descriptionText)
        val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)
        return ExpenseViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val currentItem = expenseList[position]
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

        holder.categoryText.text = currentItem.category
        holder.amountText.text = String.format("₹%.2f", currentItem.amount)
        holder.dateText.text = dateFormat.format(currentItem.date)
        holder.descriptionText.text = currentItem.description

        holder.deleteButton.setOnClickListener {
            deleteListener?.onItemDelete(position)
        }
    }

    override fun getItemCount() = expenseList.size
}