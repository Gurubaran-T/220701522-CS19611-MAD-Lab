package com.example.expensetracker

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

const val ADD_EXPENSE_REQUEST = 1
const val PREFS_NAME = "ExpensePrefs"
const val EXPENSE_LIST_KEY = "expense_list"

class MainActivity : AppCompatActivity(), ExpenseAdapter.OnItemDeleteListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ExpenseAdapter
    private lateinit var totalExpenseText: TextView
    private lateinit var addExpenseButton: Button
    private lateinit var expenseChartButton: Button
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var emptyStateText: TextView  // For showing empty message

    private val expenseList = ArrayList<Expense>()
    private var totalExpense = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Set up toolbar
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.title = "My Expenses"

        // Initialize views
        recyclerView = findViewById(R.id.expenseRecyclerView)
        totalExpenseText = findViewById(R.id.totalExpenseText)
        addExpenseButton = findViewById(R.id.addExpenseButton)
        expenseChartButton = findViewById(R.id.expenseChartButton)
        emptyStateText = findViewById(R.id.emptyStateText)  // Initialize empty state view

        // Setup RecyclerView
        adapter = ExpenseAdapter(expenseList)
        adapter.setOnItemDeleteListener(this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Load saved expenses
        loadExpenses()

        // Add swipe to delete functionality
        setupSwipeToDelete()

        // Update UI based on whether list is empty
        updateEmptyState()

        // Button click listeners
        addExpenseButton.setOnClickListener {
            val intent = Intent(this, AddExpenseActivity::class.java)
            startActivityForResult(intent, ADD_EXPENSE_REQUEST)
        }

        expenseChartButton.setOnClickListener {
            if (expenseList.isEmpty()) {
                showEmptyListAlert()
            } else {
                val intent = Intent(this, ChartActivity::class.java)
                intent.putExtra("totalExpense", totalExpense)
                intent.putExtra("expenseList", expenseList)
                startActivity(intent)
            }
        }
    }

    private fun showEmptyListAlert() {
        AlertDialog.Builder(this)
            .setTitle("No Expenses")
            .setMessage("There are no expenses to display. Please add some expenses first.")
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
            .show()
    }

    private fun updateEmptyState() {
        if (expenseList.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyStateText.visibility = View.VISIBLE
            expenseChartButton.isEnabled = false
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyStateText.visibility = View.GONE
            expenseChartButton.isEnabled = true
        }
    }

    private fun loadExpenses() {
        try {
            val json = sharedPreferences.getString(EXPENSE_LIST_KEY, null)
            if (json != null) {
                val type = object : TypeToken<ArrayList<Expense>>() {}.type
                val savedList = Gson().fromJson<ArrayList<Expense>>(json, type)
                expenseList.clear()
                expenseList.addAll(savedList)
                calculateTotalExpense()
                adapter.notifyDataSetChanged()
            }
        } catch (e: Exception) {
            // Handle corrupted preference data
            AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage("Could not load saved expenses. Starting fresh.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        }
    }

    private fun saveExpenses() {
        try {
            val editor = sharedPreferences.edit()
            val json = Gson().toJson(expenseList)
            editor.putString(EXPENSE_LIST_KEY, json)
            editor.apply()
        } catch (e: Exception) {
            // Handle saving error
            AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage("Failed to save expenses")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        }
    }

    private fun setupSwipeToDelete() {
        val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                showDeleteConfirmationDialog(position)
            }
        })
        itemTouchHelper.attachToRecyclerView(recyclerView)
    }

    private fun showDeleteConfirmationDialog(position: Int) {
        if (position < 0 || position >= expenseList.size) return

        AlertDialog.Builder(this)
            .setTitle("Delete Expense")
            .setMessage("Are you sure you want to delete this expense?")
            .setPositiveButton("Delete") { _, _ ->
                expenseList.removeAt(position)
                adapter.notifyItemRemoved(position)
                calculateTotalExpense()
                saveExpenses()
                updateEmptyState() // Check if list is now empty
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                adapter.notifyItemChanged(position)
            }
            .create()
            .show()
    }

    override fun onItemDelete(position: Int) {
        showDeleteConfirmationDialog(position)
    }

    private fun addSampleData() {
        try {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            expenseList.add(Expense("Food", 15.50, dateFormat.parse("10/05/2023"), "Lunch at cafe"))
            expenseList.add(Expense("Transport", 5.20, dateFormat.parse("11/05/2023"), "Bus ticket"))
            expenseList.add(Expense("Shopping", 45.99, dateFormat.parse("12/05/2023"), "New shoes"))
            expenseList.add(Expense("Entertainment", 12.00, dateFormat.parse("13/05/2023"), "Movie ticket"))

            calculateTotalExpense()
            adapter.notifyDataSetChanged()
            saveExpenses()
            updateEmptyState()
        } catch (e: Exception) {
            AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage("Failed to add sample data")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        }
    }

    private fun calculateTotalExpense() {
        try {
            totalExpense = expenseList.sumOf { it.amount }
            totalExpenseText.text = String.format("Total: ₹%.2f", totalExpense)
        } catch (e: Exception) {
            totalExpenseText.text = "Total: ₹0.00"
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == ADD_EXPENSE_REQUEST && resultCode == RESULT_OK) {
            try {
                val newExpense = data?.getSerializableExtra("newExpense") as? Expense
                newExpense?.let {
                    expenseList.add(it)
                    calculateTotalExpense()
                    adapter.notifyDataSetChanged()
                    saveExpenses()
                    updateEmptyState()
                }
            } catch (e: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("Failed to add new expense")
                    .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                    .create()
                    .show()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> true
            R.id.menu_about -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}